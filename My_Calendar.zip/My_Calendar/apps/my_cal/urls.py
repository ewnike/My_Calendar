from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index, name="index"),
    url(r'^$', views.process_search, name="process_search"),
    url(r'^getAppointments/$',views.getAppointments),
    url(r'^createAppointment$',views.createAppointment)
]
