function getAppointments(){
  console.log("I am in this function!")
  $.ajax({
    url : "getAppointments/",
    data: 'json',

    success: function(serverResponse) {
      console.log('success. serverResponse', serverResponse)
    }
  )};
)};
//       // pay careful attention to the response object
//       console.log('the response object:');
//       console.log(serverResponse);
//       console.log('HITTING THIS');
//       var items = "";
//       $.each(serverResponse, function(key, val) {
//         console.log('THIS IS THE KEY', key);
//         console.log('THIS IS THE VAL', val);
//         items +=
//           "<tr>" +
//           "<td>" + val.date + "</td>" +
//           "<td>" + val.time + "</td>" +
//           "<td>" + val.description + "</td>" +
//           "</tr>"
//       },
//       document.getElementById("toggletable").innerHTML = items;
//     },
//     'json'
//   });
//   // don't forget this 'false' -- without it, the 'submit' cycle will continue, and the page will refresh
//   return false;
// },
