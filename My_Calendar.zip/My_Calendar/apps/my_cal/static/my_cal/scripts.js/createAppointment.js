function createAppointment(){
  console.log("form is working!") // sanity check
    $.ajax({
        url : "createAppointment/", // the endpoint
        type : "POST", // http method
        data : { the_appointment : $('#calendar_form').val() }, // data sent with the post request

    // handle a successful response
    success : function(json) {
        $('#calendar_form').val(''); // remove the value from the input
        console.log(json); // log the returned json to the console
        console.log("success"); // another sanity check
      }
 });
};  
