# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect, reverse, HttpResponse
from django.contrib import messages
from . models import *
from django.db.models import Count
from datetime import datetime
from datetime import timedelta
import json
import requests
from django.core import serializers
from django.http import JsonResponse


# Create your views here.
def index(request):
    return render(request, 'my_cal/index.html')

def process_search(request):
    return redirect('my_cal:index')



def getAppointments(request):
    appointments = Appointments.objects.all()
    response = serializers.serialize("json", appointments)
    return HttpResponse(response, content_type = 'application/json')
    

def createAppointment(request):
    if request.method == "POST":
        errors = "false"
        datetimevar = request.POST['date'] + str(" ") + str(request.POST['time'])
        print "concat date and time value is ", datetimevar
        today = datetime.now()
        Appointments.objects.create(date = request.POST['date'], time = request.POST['time'], description=request.POST['description'])
    return render(request, 'my_cal/index.html')
