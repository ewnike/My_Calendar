# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class MyCalConfig(AppConfig):
    name = 'my_cal'
